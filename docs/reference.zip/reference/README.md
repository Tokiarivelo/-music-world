# Music World — 3D Reference Images for Realism

> **Notice:** Reference images collected in `docs/reference/` for 3D modeling and procedural synthesis.
> This folder is git-ignored and not committed (`.gitignore`). In accordance with project policy, only **CC0 / Public Domain** assets
> can be directly bundled into the repository (e.g. in `apps/web/public/`); other photos are **for visual reference only**.

## Overview by Object Type

| Category | Object Type | Total Images | CC0 Assets (Repo Usable) | Reference Only (Look Only) |
|---|---|---|---|---|
| [`01_tree/`](./01_tree/) | **Tree** | 7 | 3 | 4 |
| [`02_conifer/`](./02_conifer/) | **Conifer** | 6 | 2 | 4 |
| [`03_bush/`](./03_bush/) | **Bush** | 5 | 3 | 2 |
| [`04_cloud/`](./04_cloud/) | **Sky / Cloud** | 5 | 2 | 3 |
| [`05_car/`](./05_car/) | **Car / Wheel** | 7 | 3 | 4 |
| [`06_airplane/`](./06_airplane/) | **Airplane** | 14 | 4 | 10 |
| [`07_bicycle/`](./07_bicycle/) | **Bicycle** | 4 | 0 | 4 |
| [`08_bird/`](./08_bird/) | **Bird** | 4 | 0 | 4 |
| [`09_sun_moon/`](./09_sun_moon/) | **Sky / Sunset** | 5 | 2 | 3 |
| [`10_rain_storm/`](./10_rain_storm/) | **Rain and storm** | 5 | 1 | 4 |
| [`11_ground_hills/`](./11_ground_hills/) | **Sky / Hills** | 10 | 8 | 2 |
| [`12_aurora/`](./12_aurora/) | **Aurora** | 4 | 1 | 3 |
| [`13_polyhaven_ambientcg/`](./13_polyhaven_ambientcg/) | **Poly Haven & ambientCG (Candidates)** | 20 | 20 | 0 |

**Total reference images:** 96

## Detailed Asset Catalog

### `01_tree` — Tree

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`jacaranda_tree_model_render.png`](./01_tree/jacaranda_tree_model_render.png) | Poly Haven CC0 3D / HDRI asset: jacaranda_tree | [CC0](https://polyhaven.com/a/jacaranda_tree) | ✅ **CC0 / Public Domain** |
| [`bark014_tree_bark_preview.png`](./01_tree/bark014_tree_bark_preview.png) | ambientCG CC0 PBR material preview: Bark014 | [CC0](https://ambientcg.com/view?id=Bark014) | ✅ **CC0 / Public Domain** |
| [`bark012_tree_bark_preview.png`](./01_tree/bark012_tree_bark_preview.png) | ambientCG CC0 PBR material preview: Bark012 | [CC0](https://ambientcg.com/view?id=Bark012) | ✅ **CC0 / Public Domain** |
| [`deciduous_tree_silhouette.jpg`](./01_tree/deciduous_tree_silhouette.jpg) | Deciduous tree silhouette showing branch architecture | [PDM-owner](https://commons.wikimedia.org/wiki/File:Landscape_with_River_(SM_18).png) | 👁️ *Reference Only* |
| [`tree_crown_leaves_cluster.jpg`](./01_tree/tree_crown_leaves_cluster.jpg) | Leaves cluster and foliage clumps | [No restrictions](https://commons.wikimedia.org/wiki/File:Annual_descriptive_catalogue_-_seeds_%26c._(1897)_(19926308943).jpg) | 👁️ *Reference Only* |
| [`oak_tree_whole_side.jpg`](./01_tree/oak_tree_whole_side.jpg) | Whole oak tree from the side, summer foliage and crown shape | [CC BY 4.0](https://commons.wikimedia.org/wiki/File:Moscow._A_500-year-old_oak_tree_in_Kolomenskoe1.jpg) | 👁️ *Reference Only* |
| [`tree_trunk_roots_flare.jpg`](./01_tree/tree_trunk_roots_flare.jpg) | Tree trunk base with flaring buttress roots and bark texture | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Buttress_tree_trunk_cedar_grove_track.JPG) | 👁️ *Reference Only* |

### `02_conifer` — Conifer

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`fir_sapling_model_render.png`](./02_conifer/fir_sapling_model_render.png) | Poly Haven CC0 3D / HDRI asset: fir_sapling | [CC0](https://polyhaven.com/a/fir_sapling) | ✅ **CC0 / Public Domain** |
| [`pine_sapling_small_model_render.png`](./02_conifer/pine_sapling_small_model_render.png) | Poly Haven CC0 3D / HDRI asset: pine_sapling_small | [CC0](https://polyhaven.com/a/pine_sapling_small) | ✅ **CC0 / Public Domain** |
| [`fir_tree_drooping_branches.jpg`](./02_conifer/fir_tree_drooping_branches.jpg) | Fir tree drooping tier branches | [No restrictions](https://commons.wikimedia.org/wiki/File:Catalogue_of_Pomona_Nurseries_(1899)_(20366029960).jpg) | 👁️ *Reference Only* |
| [`norway_spruce_silhouette.jpg`](./02_conifer/norway_spruce_silhouette.jpg) | Conifer silhouette spire profile | [CC BY-SA 3.0](https://commons.wikimedia.org/wiki/File:Midnight_sun_and_spruce_trees,_Inuvik,_NT.jpg) | 👁️ *Reference Only* |
| [`pine_needles_branch_closeup.jpg`](./02_conifer/pine_needles_branch_closeup.jpg) | Pine needles cluster and branch detail | [CC BY 4.0](https://commons.wikimedia.org/wiki/File:(Sciadopitys_verticillata_close-up_at_Mount_Unzen,_Japan)_-_DPLA_-_7df45562bc07dcc02d83db26b7adcba4.jpg) | 👁️ *Reference Only* |
| [`norway_spruce_whole_tree.jpg`](./02_conifer/norway_spruce_whole_tree.jpg) | Whole Norway spruce (Picea abies) showing spire silhouette | [CC BY-SA 3.0 ee](https://commons.wikimedia.org/wiki/File:Kuusk_Keila-Paldiski_rdt_%C3%A4%C3%A4res.jpg) | 👁️ *Reference Only* |

### `03_bush` — Bush

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`shrub_03_model_render.png`](./03_bush/shrub_03_model_render.png) | Poly Haven CC0 3D / HDRI asset: shrub_03 | [CC0](https://polyhaven.com/a/shrub_03) | ✅ **CC0 / Public Domain** |
| [`shrub_02_model_render.png`](./03_bush/shrub_02_model_render.png) | Poly Haven CC0 3D / HDRI asset: shrub_02 | [CC0](https://polyhaven.com/a/shrub_02) | ✅ **CC0 / Public Domain** |
| [`leaf001_foliage_preview.png`](./03_bush/leaf001_foliage_preview.png) | ambientCG CC0 PBR material preview: Leaf001 | [CC0](https://ambientcg.com/view?id=Leaf001) | ✅ **CC0 / Public Domain** |
| [`boxwood_shrub_clump_shape.jpg`](./03_bush/boxwood_shrub_clump_shape.jpg) | Rounded boxwood clump shape | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Formal_garden_Harlow_Museum_%26_Walled_Gardens,_Essex_01.jpg) | 👁️ *Reference Only* |
| [`hedge_bush_green_foliage.jpg`](./03_bush/hedge_bush_green_foliage.jpg) | Hedge foliage texture and green color variations | [No restrictions](https://commons.wikimedia.org/wiki/File:C._M._Hobbs_and_Sons_-_hardy_fruits,_ornamental_trees,_evergreens,_shrubs,_vines,_roses,_perennials,_hedge_plants_and_everything_for_the_hardy_garden_(1917)_(20471158539).jpg) | 👁️ *Reference Only* |

### `04_cloud` — Sky / Cloud

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`wasteland_clouds_puresky_preview.png`](./04_cloud/wasteland_clouds_puresky_preview.png) | Poly Haven CC0 3D / HDRI asset: wasteland_clouds_puresky | [CC0](https://polyhaven.com/a/wasteland_clouds_puresky) | ✅ **CC0 / Public Domain** |
| [`cumulus_humilis_side_view.jpg`](./04_cloud/cumulus_humilis_side_view.jpg) | Cumulus humilis low fair-weather clouds | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Cumulus_humilis_Sch%C3%B6nwald_im_Schwarzwald_20180810.jpg) | 👁️ *Reference Only* |
| [`stratocumulus_sky_layer.jpg`](./04_cloud/stratocumulus_sky_layer.jpg) | Stratocumulus cloud layer and undulating texture | [CC0](https://commons.wikimedia.org/wiki/File:Panza_de_burro_(belly_of_the_donkey),_grey-bellied_stratocumulus_clouds_in_the_Canary_Islands.jpg) | ✅ **CC0 / Public Domain** |
| [`cumulonimbus_storm_anvil_cloud.jpg`](./04_cloud/cumulonimbus_storm_anvil_cloud.jpg) | Towering cumulonimbus with anvil top | [CC BY 4.0](https://commons.wikimedia.org/wiki/File:Anvil_storm_cloud.jpg) | 👁️ *Reference Only* |
| [`cumulus_clouds_blue_sky_flat_base.jpg`](./04_cloud/cumulus_clouds_blue_sky_flat_base.jpg) | Side view of cumulus with distinct flat base and illuminated rounded top | [CC BY-SA 3.0](https://commons.wikimedia.org/wiki/File:Cumulus_mediocris-1.jpg) | 👁️ *Reference Only* |

### `05_car` — Car / Wheel

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`metal049a_car_rim_preview.png`](./05_car/metal049a_car_rim_preview.png) | ambientCG CC0 PBR material preview: Metal049A | [CC0](https://ambientcg.com/view?id=Metal049A) | ✅ **CC0 / Public Domain** |
| [`paintedmetal002_car_paint_preview.png`](./05_car/paintedmetal002_car_paint_preview.png) | ambientCG CC0 PBR material preview: PaintedMetal002 | [CC0](https://ambientcg.com/view?id=PaintedMetal002) | ✅ **CC0 / Public Domain** |
| [`technical_car_blueprint.png`](./05_car/technical_car_blueprint.png) | Orthographic automotive blueprint (side, top, front outlines) | [CC0](https://commons.wikimedia.org/wiki/File:Technical_car_blueprint.png) | ✅ **CC0 / Public Domain** |
| [`sedan_car_side_profile_photo.jpg`](./05_car/sedan_car_side_profile_photo.jpg) | Sedan car side profile orthographic view and roofline geometry | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:1959_Edsel_Ranger_2-door_sedan,_right_side_(2022_Back_to_the_50%27s_Weekend).jpg) | 👁️ *Reference Only* |
| [`hatchback_front_orthographic.jpg`](./05_car/hatchback_front_orthographic.jpg) | Hatchback direct front view showing grille, stance and headlights | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Volkswagen_Golf_Alltrack_(2016)_IMG_5571.jpg) | 👁️ *Reference Only* |
| [`car_wheel_alloy_rim_closeup.jpg`](./05_car/car_wheel_alloy_rim_closeup.jpg) | Close-up of car wheel alloy rim spokes, center cap and tire bead | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Brushed_Wheel_Faces.jpg) | 👁️ *Reference Only* |
| [`car_headlight_closeup.jpg`](./05_car/car_headlight_closeup.jpg) | Automotive headlight reflector lens and bezel close-up detail | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Headlight_of_a_Soviet_car.jpg) | 👁️ *Reference Only* |

### `06_airplane` — Airplane

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`cessna_172_three_view_blueprint.png`](./06_airplane/cessna_172_three_view_blueprint.png) | Cessna 172 3-view blueprint (top, side, front) | [Public domain](https://commons.wikimedia.org/wiki/File:Cessna_172G_Skyhawk_3-view_line_drawing.png) | ✅ **CC0 / Public Domain** |
| [`light_aircraft_top_view.jpg`](./06_airplane/light_aircraft_top_view.jpg) | Light aircraft wing planform from above | [CC BY 2.0](https://commons.wikimedia.org/wiki/File:Beechcraft_AT-11,_Cuban_Air_Force_(51674908619).jpg) | 👁️ *Reference Only* |
| [`small_propeller_airplane_side_view.jpg`](./06_airplane/small_propeller_airplane_side_view.jpg) | Small propeller aircraft side view profile | [CC BY 4.0](https://commons.wikimedia.org/wiki/File:Airside_F_at_Tampa_International_Airport_nighttime_long_exposure.jpg) | 👁️ *Reference Only* |
| [`airliner_side_profile.jpg`](./06_airplane/airliner_side_profile.jpg) | Commercial airliner side silhouette, sweep angle and engine cowlings | [CC BY 2.0](https://commons.wikimedia.org/wiki/File:Luxair_Boeing_737-700_at_Vienna_Airport.jpg) | 👁️ *Reference Only* |
| [`piper_cherokee_three_view_blueprint.png`](./06_airplane/piper_cherokee_three_view_blueprint.png) | Piper PA-28 Cherokee low-wing 3-view blueprint (top, side, front orthographic) | [Public domain](https://commons.wikimedia.org/wiki/File:Piper_PA-28-140_Cherokee_3-view_line_drawing.png) | ✅ **CC0 / Public Domain** |
| [`airbus_a320_three_view_blueprint.png`](./06_airplane/airbus_a320_three_view_blueprint.png) | Airbus A320 commercial twin-jet 3-view orthographic blueprint | [CC BY-SA 3.0](https://commons.wikimedia.org/wiki/File:Airbus_A320_v1.0.png) | 👁️ *Reference Only* |
| [`boeing_737_front_orthographic.svg`](./06_airplane/boeing_737_front_orthographic.svg) | Boeing 737 front view orthographic projection (fuselage cross-section, dihedral, engines) | [Public domain](https://commons.wikimedia.org/wiki/File:Boeing_737-300_front_view.svg) | ✅ **CC0 / Public Domain** |
| [`concorde_supersonic_three_view_blueprint.png`](./06_airplane/concorde_supersonic_three_view_blueprint.png) | Concorde supersonic transport 3-view blueprint (ogival delta wing planform & droop nose) | [CC BY-SA 3.0](https://commons.wikimedia.org/wiki/File:Concorde_v1.0.png) | 👁️ *Reference Only* |
| [`cessna_172_front_view_photo.jpg`](./06_airplane/cessna_172_front_view_photo.jpg) | Cessna 172 high-wing front 3/4 photo showing propeller spinner, engine cowl and strut geometry | [GFDL](https://commons.wikimedia.org/wiki/File:Cessna_172_(5736732630).jpg) | 👁️ *Reference Only* |
| [`cirrus_sr22_in_flight_photo.jpg`](./06_airplane/cirrus_sr22_in_flight_photo.jpg) | Modern low-wing composite private aircraft in banking flight (wing dihedral, canopy bubble) | [CC BY-SA 2.0](https://commons.wikimedia.org/wiki/File:Cirrus_SR22_N310TN_(3333357289).jpg) | 👁️ *Reference Only* |
| [`airbus_a380_widebody_flight_profile.jpg`](./06_airplane/airbus_a380_widebody_flight_profile.jpg) | Widebody 4-engine jet airliner side profile in flight showing double-deck fuselage & wing sweep | [GFDL 1.2](https://commons.wikimedia.org/wiki/File:Airbus_A380-841,_Lufthansa_AN1997308.jpg) | 👁️ *Reference Only* |
| [`seaplane_floatplane_dhc2_beaver.jpg`](./06_airplane/seaplane_floatplane_dhc2_beaver.jpg) | Bush seaplane on twin floats resting on water with propeller and radial engine cowling | [GFDL](https://commons.wikimedia.org/wiki/File:DHC-2_Beaver_floats_(5730018146).jpg) | 👁️ *Reference Only* |
| [`biplane_staggerwing_side_view.jpg`](./06_airplane/biplane_staggerwing_side_view.jpg) | Classic staggered-wing biplane side profile showing dual wing chords and tail wheel gear | [Public domain](https://commons.wikimedia.org/wiki/File:Beech_YC-43_39-139_side_view_in_London.jpg) | ✅ **CC0 / Public Domain** |
| [`aircraft_propeller_blade_detail.jpg`](./06_airplane/aircraft_propeller_blade_detail.jpg) | Propeller blade twist, airfoil cross-section camber, hub and leading-edge detail | [CC BY-SA 3.0](https://commons.wikimedia.org/wiki/File:Propeller_blade_with_TKS_deice_boot_detail.JPG) | 👁️ *Reference Only* |

### `07_bicycle` — Bicycle

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`city_bicycle_side_view.jpg`](./07_bicycle/city_bicycle_side_view.jpg) | Commuter bicycle complete side view profile | [Licence Ouverte](https://commons.wikimedia.org/wiki/File:Fonds_Andr%C3%A9_Raymond_(1925-2011)_-_Tunisie_-_Tunis_-_Rue_Tourbet_el_Bey_(M%C3%A9diHAL_4209595).jpg) | 👁️ *Reference Only* |
| [`bicycle_frame_geometry_diagram.png`](./07_bicycle/bicycle_frame_geometry_diagram.png) | Frame geometry diagram with tube proportions | [CC BY 2.0](https://commons.wikimedia.org/wiki/File:Bike_frame_geometry_scheme.jpg) | 👁️ *Reference Only* |
| [`city_bicycle_side_view_photo.jpg`](./07_bicycle/city_bicycle_side_view_photo.jpg) | Complete side view of commuter bicycle showing frame triangles and fork | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Kellner_bicycle_side_view.JPG) | 👁️ *Reference Only* |
| [`bicycle_wheel_spokes_hub_closeup.jpg`](./07_bicycle/bicycle_wheel_spokes_hub_closeup.jpg) | Bicycle wheel spokes cross pattern, rim and axle hub close-up | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Bicycle_front_wheel_(1)_(cropped_to_bicycle_fork).jpg) | 👁️ *Reference Only* |

### `08_bird` — Bird

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`swallow_flight_profile.jpg`](./08_bird/swallow_flight_profile.jpg) | Slender swept-wing swallow silhouette | [CC BY-SA 3.0](https://commons.wikimedia.org/wiki/File:Barn_Swallow_Flying_(98006487).jpeg) | 👁️ *Reference Only* |
| [`flock_of_birds_sky_silhouette.jpg`](./08_bird/flock_of_birds_sky_silhouette.jpg) | Flock spacing and varied flight poses | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Aananda_Bazar_Sky_View.jpg) | 👁️ *Reference Only* |
| [`bird_flight_wings_up_pose.jpg`](./08_bird/bird_flight_wings_up_pose.jpg) | Seagull in flight pose with wings raised on up-stroke | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Flying_seagull_with_outstretched_wings_number_one.JPG) | 👁️ *Reference Only* |
| [`bird_flight_wings_down_gliding.jpg`](./08_bird/bird_flight_wings_down_gliding.jpg) | Gull gliding posture with wings outstretched horizontally | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Gull_soaring_over_Fir_Island,_WA_-_01.jpg) | 👁️ *Reference Only* |

### `09_sun_moon` — Sky / Sunset

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`qwantani_dusk_1_puresky_preview.png`](./09_sun_moon/qwantani_dusk_1_puresky_preview.png) | Poly Haven CC0 3D / HDRI asset: qwantani_dusk_1_puresky | [CC0](https://polyhaven.com/a/qwantani_dusk_1_puresky) | ✅ **CC0 / Public Domain** |
| [`syferfontein_1d_clear_puresky_preview.png`](./09_sun_moon/syferfontein_1d_clear_puresky_preview.png) | Poly Haven CC0 3D / HDRI asset: syferfontein_1d_clear_puresky | [CC0](https://polyhaven.com/a/syferfontein_1d_clear_puresky) | ✅ **CC0 / Public Domain** |
| [`sun_rays_through_clouds.jpg`](./09_sun_moon/sun_rays_through_clouds.jpg) | Crepuscular sunbeam shafts diverging from clouds | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Crepuscular_rays_1.jpg) | 👁️ *Reference Only* |
| [`full_moon_clear_night_sky.jpg`](./09_sun_moon/full_moon_clear_night_sky.jpg) | Full moon spherical disc and surface maria contrast | [CC BY 4.0](https://commons.wikimedia.org/wiki/File:ALMA_and_a_Starry_Night.jpg) | 👁️ *Reference Only* |
| [`crescent_moon_clear_sky.jpg`](./09_sun_moon/crescent_moon_clear_sky.jpg) | Crescent cusp curve and subtle earthshine glow | [CC BY 4.0](https://commons.wikimedia.org/wiki/File:Earthshine-_the_Moon_shining_in_reflected_light_from_the_Earth_(eso1210c).jpg) | 👁️ *Reference Only* |

### `10_rain_storm` — Rain and storm

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`lightning_forked_bolt_night.jpg`](./10_rain_storm/lightning_forked_bolt_night.jpg) | Crisp forked lightning bolt channel striking ground at night | [CC BY 2.0](https://commons.wikimedia.org/wiki/File:Denver_Lightning.jpg) | 👁️ *Reference Only* |
| [`lightning_cloud_branches.jpg`](./10_rain_storm/lightning_cloud_branches.jpg) | Intricate stepped leader and branch discharges across cloud base | [CC BY-SA 3.0](https://commons.wikimedia.org/wiki/File:Lightning_Pritzerbe_01_(MK).jpg) | 👁️ *Reference Only* |
| [`shelf_cloud_storm_front.jpg`](./10_rain_storm/shelf_cloud_storm_front.jpg) | Low, horizontal wedge shelf cloud at leading edge of storm gust front | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Shelf_cloud_over_Asprovalta.jpg) | 👁️ *Reference Only* |
| [`rain_streaks_night_street_light.jpg`](./10_rain_storm/rain_streaks_night_street_light.jpg) | Linear streaks of falling rain illuminated against night background | [CC0](https://commons.wikimedia.org/wiki/File:Persistent_Night_Rain_In_The_Light_Of_Street_Lamp_(220669549).jpeg) | ✅ **CC0 / Public Domain** |
| [`heavy_rain_downpour_street.jpg`](./10_rain_storm/heavy_rain_downpour_street.jpg) | Heavy atmospheric rain curtains and surface water reflections | [CC BY-SA 2.0](https://commons.wikimedia.org/wiki/File:Heavy_rain_in_Castle_Street_-_geograph.org.uk_-_3105928.jpg) | 👁️ *Reference Only* |

### `11_ground_hills` — Sky / Hills

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`table_mountain_1_puresky_preview.png`](./11_ground_hills/table_mountain_1_puresky_preview.png) | Poly Haven CC0 3D / HDRI asset: table_mountain_1_puresky | [CC0](https://polyhaven.com/a/table_mountain_1_puresky) | ✅ **CC0 / Public Domain** |
| [`snow_field_puresky_preview.png`](./11_ground_hills/snow_field_puresky_preview.png) | Poly Haven CC0 3D / HDRI asset: snow_field_puresky | [CC0](https://polyhaven.com/a/snow_field_puresky) | ✅ **CC0 / Public Domain** |
| [`rock_07_model_render.png`](./11_ground_hills/rock_07_model_render.png) | Poly Haven CC0 3D / HDRI asset: rock_07 | [CC0](https://polyhaven.com/a/rock_07) | ✅ **CC0 / Public Domain** |
| [`rock_09_model_render.png`](./11_ground_hills/rock_09_model_render.png) | Poly Haven CC0 3D / HDRI asset: rock_09 | [CC0](https://polyhaven.com/a/rock_09) | ✅ **CC0 / Public Domain** |
| [`stone_01_model_render.png`](./11_ground_hills/stone_01_model_render.png) | Poly Haven CC0 3D / HDRI asset: stone_01 | [CC0](https://polyhaven.com/a/stone_01) | ✅ **CC0 / Public Domain** |
| [`grass004_lawn_preview.png`](./11_ground_hills/grass004_lawn_preview.png) | ambientCG CC0 PBR material preview: Grass004 | [CC0](https://ambientcg.com/view?id=Grass004) | ✅ **CC0 / Public Domain** |
| [`rock064_stone_preview.png`](./11_ground_hills/rock064_stone_preview.png) | ambientCG CC0 PBR material preview: Rock064 | [CC0](https://ambientcg.com/view?id=Rock064) | ✅ **CC0 / Public Domain** |
| [`grassland_horizon_landscape.jpg`](./11_ground_hills/grassland_horizon_landscape.jpg) | Clean flat horizon line dividing prairie and sky | [Public domain](https://commons.wikimedia.org/wiki/File:A_view_of_the_pairie_looking_towards_a_break_in_the_distant_ridgeline_(5e7c14ebed1d499aa5b0ae765f628406).JPG) | ✅ **CC0 / Public Domain** |
| [`rolling_hills_mist_layers.jpg`](./11_ground_hills/rolling_hills_mist_layers.jpg) | Rolling hills terrain receding into morning valley mist | [CC BY-SA 2.0](https://commons.wikimedia.org/wiki/File:Mist_Rolling_in_over_the_Eildon_Hills_-_geograph.org.uk_-_7967255.jpg) | 👁️ *Reference Only* |
| [`distant_mountains_haze_layers.jpg`](./11_ground_hills/distant_mountains_haze_layers.jpg) | Mountain ridges illustrating atmospheric perspective and depth haze | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Deep_Valley_Haze_(Clearing_View).jpg) | 👁️ *Reference Only* |

### `12_aurora` — Aurora

| File | What to keep / Key Visual Aspects | Source & License | Repo Use? |
|---|---|---|---|
| [`aurora_borealis_over_snowy_mountains.jpg`](./12_aurora/aurora_borealis_over_snowy_mountains.jpg) | Green auroral glow over snow peak and terrain | [CC BY 3.0](https://commons.wikimedia.org/wiki/File:Steinfjord_Senja_Norway_(137838339).jpeg) | 👁️ *Reference Only* |
| [`aurora_corona_zenith.jpg`](./12_aurora/aurora_corona_zenith.jpg) | Auroral corona rays radiating from geomagnetic zenith | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Auroral_Corona_Onawa_IA.jpg) | 👁️ *Reference Only* |
| [`aurora_borealis_green_curtains.jpg`](./12_aurora/aurora_borealis_green_curtains.jpg) | Luminous green auroral curtain folds draped across night sky | [CC BY-SA 4.0](https://commons.wikimedia.org/wiki/File:Aurora_in_Abisko_near_Tornetr%C3%A4sk.jpg) | 👁️ *Reference Only* |
| [`aurora_ribbon_over_snow_landscape.jpg`](./12_aurora/aurora_ribbon_over_snow_landscape.jpg) | Sweeping green auroral ribbon over snow-covered landscape | [Public domain](https://commons.wikimedia.org/wiki/File:Aurora_borealis_over_Eielson_Air_Force_Base,_Alaska.jpg) | ✅ **CC0 / Public Domain** |

